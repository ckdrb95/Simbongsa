import os
import cv2
import random
import numpy as np
import torch
from src.config import Config
from src.edge_connect import EdgeConnect
import image_preprocessing as IP

def main(mode=None):
    r"""starts the model

    Args:
        mode (int): 1: train, 2: test, 3: eval, reads from config file if not specified
    """

    #image_preprocessing
    #resize (540, 720)
    IP.resize(r'C:\Users\gurwl\OneDrive\Desktop\HyukJin\GAN\gan\edge-connect\before_image\images')  # img_dir_path
    IP.resize(r'C:\Users\gurwl\OneDrive\Desktop\HyukJin\GAN\gan\edge-connect\before_image\masks')  # mask_dir_path
    #reverse mask, systesize original + reverse_mask
    # IP.syntesize(r'C:\Users\gurwl\OneDrive\Desktop\HyukJin\GAN\gan\edge-connect\before_image\images',
    #           r'C:\Users\gurwl\OneDrive\Desktop\HyukJin\GAN\gan\edge-connect\before_image\masks')


    config = load_config(mode)

    # cuda visble devices
    os.environ['CUDA_VISIBLE_DEVICES'] = ','.join(str(e) for e in config.GPU)


    # init device
    if torch.cuda.is_available():
        config.DEVICE = torch.device("cuda")
        torch.backends.cudnn.benchmark = True   # cudnn auto-tuner
    else:
        config.DEVICE = torch.device("cpu")



    # set cv2 running threads to 1 (prevents deadlocks with pytorch dataloader)
    cv2.setNumThreads(0)


    # initialize random seed
    torch.manual_seed(config.SEED)
    torch.cuda.manual_seed_all(config.SEED)
    np.random.seed(config.SEED)
    random.seed(config.SEED)



    # build the model and initialize
    model = EdgeConnect(config)
    model.load()


    # model training
    if config.MODE == 1:
        #config.print()
        print('\nstart training...\n')
        model.train()

    # model test
    elif config.MODE == 2:
        print('\nstart testing...\n')
        model.test()

    # eval mode
    else:
        print('\nstart eval...\n')
        model.eval()


def load_config(mode=None):
    r"""loads model config

    Args:
        mode (int): 1: train, 2: test, 3: eval, reads from config file if not specified
    """

    #Options
    a = r"C:\Users\gurwl\OneDrive\Desktop\HyukJin\GAN\gan\edge-connect\scripts\checkpoints\places2\config.yml"  #config_path
    b = 2   #model
    c = r"./before_image/images"    #input_image_dir
    d = r"./before_image/masks"     #input_mask_dir
    e = ""                          #edge
    f = r"./after_image"            #output_dir


    # load config file
    config = Config(a)

    #print('mode : ', config.MODE)
    #print('model : ', config.MODEL)

    # train mode
    if mode == 1:
        config.MODE = 1
        if b:
            config.MODEL = b

    # test mode
    elif mode == 2:
        config.MODE = 2
        config.MODEL = b if b is not None else 3
        #config.MODEL = 4
        config.INPUT_SIZE = 0

        if c is not None:
            config.TEST_FLIST = c

        if d is not None:
            config.TEST_MASK_FLIST = d

        if e is not None:
            config.TEST_EDGE_FLIST = e

        if f is not None:
            config.RESULTS = f

    # eval mode
    elif mode == 3:
        config.MODE = 3
        config.MODEL = b if b is not None else 3

    return config


if __name__ == "__main__":
    main()
