from main import main
main(mode=1)