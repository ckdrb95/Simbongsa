import cv2 as cv
import os

def resize(dir_path):
    listdir = os.listdir(dir_path)
    array = []
    for i in range(len(listdir)):
        path = dir_path + "\\" + listdir[i]
        array.append(path)
        img = cv.imread(array[i], cv.IMREAD_COLOR)
        img = cv.resize(img, (540, 720), interpolation=cv.INTER_AREA)
        cv.imwrite(array[i], img)



def syntesize(img_dir_path, mask_dir_path):
    img_listdir = os.listdir(img_dir_path)
    mask_listdir = os.listdir(mask_dir_path)
    img_array = []
    mask_array = []
    for i in range(len(img_listdir)):
        img_path = img_dir_path + "\\" + img_listdir[i]
        mask_path = mask_dir_path + "\\" + mask_listdir[i]
        img_array.append(img_path)
        mask_array.append(mask_path)
        O_image = cv.imread(img_array[i], cv.IMREAD_COLOR)  # original_img
        M_image = cv.imread(mask_array[i], cv.IMREAD_COLOR) # original mask
        M_image = cv.bitwise_not(M_image)
        cv.imwrite(mask_array[i], M_image)  #reverse original_mask

        for channel in range(0, 3):
            for col in range(0, O_image.shape[0]):
                for row in range(0, O_image.shape[1]):
                    if (M_image[col][row][channel] > 100):
                        O_image[col][row][channel] = 255
        cv.imwrite(img_array[i], O_image)  # original_img + original_mask




#resize(r'C:\Users\gurwl\OneDrive\Desktop\HyukJin\GAN\gan\edge-connect\before_image\images')   #img_dir_path
#resize(r'C:\Users\gurwl\OneDrive\Desktop\HyukJin\GAN\gan\edge-connect\before_image\masks')   #mask_dir_path
#syntesize(r'C:\Users\gurwl\OneDrive\Desktop\HyukJin\GAN\gan\edge-connect\before_image\images', r'C:\Users\gurwl\OneDrive\Desktop\HyukJin\GAN\gan\edge-connect\before_image\masks')
